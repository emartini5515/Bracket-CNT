// this is a shared property service to be injected as a module 
// the shared data can be accessed inside the key/value pair array
var SharedProperties;
(function (SharedProperties) {
    var SharedPropertiesService = (function () {
        function SharedPropertiesService($rootScope) {
            var _this = this;
            this.sharedData = [];
            this.getKey = function (key) {
                return _this.sharedData[key];
            };
            this.setKey = function (key, data) {
                _this.sharedData[key] = data;
            };
        }
        SharedPropertiesService.$inject = ["$rootScope"];
        return SharedPropertiesService;
    }());
    SharedProperties.SharedPropertiesService = SharedPropertiesService;
    angular.module("dataConflictToolApp").service("sharedProperties", ["$rootScope", function ($rootScope) { return new SharedPropertiesService($rootScope); }]);
})(SharedProperties || (SharedProperties = {}));
//# sourceMappingURL=sharedProperties.js.map