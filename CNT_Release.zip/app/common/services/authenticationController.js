// this is the authentication controller
var app;
(function (app) {
    var common;
    (function (common) {
        var AuthenticationController = (function () {
            function AuthenticationController(successCallback, $uibModalInstance, dataAccessService, displayMessage, blockUi, $timeout) {
                this.successCallback = successCallback;
                this.$uibModalInstance = $uibModalInstance;
                this.dataAccessService = dataAccessService;
                this.displayMessage = displayMessage;
                this.blockUi = blockUi;
                this.$timeout = $timeout;
                this.modalInstance = $uibModalInstance;
                this.success = successCallback;
                this.dataService = dataAccessService;
                this.message = displayMessage;
            }
            AuthenticationController.prototype.ok = function () {
                var _this = this;
                var callback = function () {
                    _this.modalInstance.close();
                    _this.success();
                };
                var resource = this.dataService.authenticateUser(this.username, this.password);
                var self = this;
                resource.query(function (data) {
                    if (data[0] == "true") {
                        callback();
                    }
                    else {
                        _this.blockUi.start("Authentication Failed!");
                        _this.$timeout(function () {
                            self.blockUi.stop();
                        }, 2000);
                        console.log("Authentication Failed");
                    }
                }, function (error) {
                    console.log("Error authenticating: " + error);
                });
            };
            ;
            AuthenticationController.prototype.close = function () {
                this.modalInstance.close();
            };
            ;
            AuthenticationController.$inject = ["successCallback", "$uibModalInstance", "dataAccessService", "displayMessage", "blockUI", "$timeout"];
            return AuthenticationController;
        }());
        common.AuthenticationController = AuthenticationController;
        angular
            .module("common.services")
            .controller("AuthenticationController", AuthenticationController);
    })(common = app.common || (app.common = {}));
})(app || (app = {}));
//# sourceMappingURL=authenticationController.js.map