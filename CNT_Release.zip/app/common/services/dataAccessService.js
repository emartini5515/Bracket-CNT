// this is the data access service
// a service to be used to access the MVC controller from Angular
// Note: An Angular resource will expect to have a list back from the controller or it will throw an exception
var app;
(function (app) {
    var common;
    (function (common) {
        var DataAccessService = (function () {
            function DataAccessService($resource, $http) {
                this.$resource = $resource;
                this.$http = $http;
            }
            // Package Conflict Search
            DataAccessService.prototype.getStudyResource = function (userName) {
                return this.$resource("/SubjectVisitSearch/getAllStudies", { userName: userName });
            };
            DataAccessService.prototype.getSelectedCountryResource = function (studyId, protocolId) {
                return this.$resource("/SubjectVisitSearch/getSelectedCountries", { studyId: studyId, studyProtocolId: protocolId });
            };
            DataAccessService.prototype.getSelectedStudyProtocolResource = function (studyId) {
                return this.$resource("/SubjectVisitSearch/getSelectedStudyProtocols", { studyId: studyId });
            };
            DataAccessService.prototype.getSelectedSiteResource = function (studyId, protocolId, countryId) {
                return this.$resource("/SubjectVisitSearch/getSelectedSites", { studyId: studyId, studyProtocolId: protocolId, countryId: countryId });
            };
            DataAccessService.prototype.getSelectedVisitResource = function (studyId, protocolId) {
                return this.$resource("/SubjectVisitSearch/getSelectedVisits", { studyId: studyId, studyProtocolId: protocolId });
            };
            DataAccessService.prototype.getSelectedSubjectVisitListResource = function (selectedStudy, selectedCountry, selectedProtocol, selectedSite, selectedSubjectId, selectedVisit, selectedDate, selectedPackageId) {
                return this.$resource("/SubjectVisitSearch/getSelectedSubjectVisitList", {
                    studyId: selectedStudy, countryId: selectedCountry, studyProtocolId: selectedProtocol, studySiteId: selectedSite, sponsorSubjectId: selectedSubjectId,
                    visitId: selectedVisit, visitDate: selectedDate, packageId: selectedPackageId
                });
            };
            DataAccessService.prototype.reprocessPackages = function (subjectVisitPackages, userName, selectedStudy, selectedCountry, selectedProtocol, selectedSite, selectedSubjectId, selectedVisit, selectedDate, selectedPackageId) {
                return this.$resource("/SubjectVisitSearch/reprocessPackages", {
                    subjectVisitPackages: subjectVisitPackages,
                    userName: userName,
                    studyId: selectedStudy,
                    countryId: selectedCountry,
                    studyProtocolId: selectedProtocol,
                    studySiteId: selectedSite,
                    sponsorSubjectId: selectedSubjectId,
                    visitId: selectedVisit,
                    visitDate: selectedDate,
                    packageId: selectedPackageId
                });
            };
            DataAccessService.prototype.getDataConflictInterviewItemDetail = function (packageId, interviewItemId) {
                return this.$resource("/conflictPackage/GetDataConflictInterviewItemDetail", { packageId: packageId, interviewItemId: interviewItemId });
            };
            DataAccessService.prototype.getDataConflictInterviewItemResponses = function (packageId, interviewItemId) {
                return this.$resource("/conflictPackage/GetDataConflictInterviewItemResponses", { packageId: packageId, interviewItemId: interviewItemId });
            };
            DataAccessService.prototype.getDataConflictInterviewItemTotals = function (packageId, interviewItemId) {
                return this.$resource("/conflictPackage/GetDataConflictInterviewItemTotals", { packageId: packageId, interviewItemId: interviewItemId });
            };
            DataAccessService.prototype.getDataConflictInterviewItemTimeStamps = function (packageId, interviewItemId) {
                return this.$resource("/conflictPackage/GetDataConflictInterviewItemTimeStamps", { packageId: packageId, interviewItemId: interviewItemId });
            };
            DataAccessService.prototype.getDataConflictInterviewItemAlerts = function (packageId, interviewItemId) {
                return this.$resource("/conflictPackage/GetDataConflictInterviewItemAlerts", { packageId: packageId, interviewItemId: interviewItemId });
            };
            DataAccessService.prototype.getDataConflictInterviewItemComments = function (packageId, interviewItemId) {
                return this.$resource("/conflictPackage/GetDataConflictInterviewItemComments", { packageId: packageId, interviewItemId: interviewItemId });
            };
            DataAccessService.prototype.getDataConflictInterviewItemAttachments = function (packageId, interviewItemId) {
                return this.$resource("/conflictPackage/GetDataConflictInterviewItemAttachments", { packageId: packageId, interviewItemId: interviewItemId });
            };
            DataAccessService.prototype.getDataConflictInterviewItemFiles = function (packageId, interviewItemId) {
                return this.$resource("/conflictPackage/GetDataConflictInterviewItemFiles", { packageId: packageId, interviewItemId: interviewItemId });
            };
            DataAccessService.prototype.validateDataConflictOnSave = function (subjectVisitPackageId, subjectVisitInterviewItemId, statusInternalNameInterviewItem, statusInternalNameSubject, statusInternalNameVisit, statusInternalNameBlindedRaters, statusInternalNameVisitComments, statusInternalNameVisitAttachments) {
                var dataObject = {
                    subjectVisitPackageId: subjectVisitPackageId,
                    subjectVisitInterviewItemId: subjectVisitInterviewItemId,
                    statusInternalNameInterviewItem: statusInternalNameInterviewItem,
                    statusInternalNameSubject: statusInternalNameSubject,
                    statusInternalNameVisit: statusInternalNameVisit,
                    statusInternalNameBlindedRaters: statusInternalNameBlindedRaters,
                    statusInternalNameVisitComments: statusInternalNameVisitComments,
                    statusInternalNameVisitAttachments: statusInternalNameVisitAttachments
                };
                return this.$resource("/conflictPackage/ValidateDataConflictOnSave", dataObject);
            };
            DataAccessService.prototype.saveDataConflictStatusSubjectVisit = function (subjectVisitPackageId, statusInternalNameSubject, statusInternalNameVisit, statusInternalNameBlindedRaters, statusInternalNameVisitComments, statusInternalNameVisitAttachments, comment, userName) {
                var saveSuccessful = this.$resource("/conflictPackage/SaveDataConflictStatusSubjectVisit", {
                    subjectVisitPackageId: subjectVisitPackageId,
                    statusInternalNameSubject: statusInternalNameSubject,
                    statusInternalNameVisit: statusInternalNameVisit,
                    statusInternalNameBlindedRaters: statusInternalNameBlindedRaters,
                    statusInternalNameVisitComments: statusInternalNameVisitComments,
                    statusInternalNameVisitAttachments: statusInternalNameVisitAttachments,
                    comment: comment,
                    userName: userName
                });
                return saveSuccessful;
            };
            DataAccessService.prototype.saveDataConflictStatusInterviewItem = function (subjectVisitPackageId, subjectVisitInterviewItemId, statusInternalNameInterviewItem, userName) {
                var saveSuccessful = this.$resource("/conflictPackage/SaveDataConflictStatusInterviewItem", {
                    subjectVisitPackageId: subjectVisitPackageId,
                    subjectVisitInterviewItemId: subjectVisitInterviewItemId,
                    statusInternalNameInterviewItem: statusInternalNameInterviewItem,
                    userName: userName
                });
                return saveSuccessful;
            };
            // --> end of Package Conflict Search
            // Manage Users
            DataAccessService.prototype.getDataConflictApplicationUsers = function (firstName, lastName, roleId) {
                var users = this.$resource("/ManageUsers/GetDataConflictUsers", { firstName: firstName, lastName: lastName, roleId: roleId });
                return users;
            };
            DataAccessService.prototype.getDataConflictApplicationUserStudies = function (dataConflictUserId) {
                return this.$resource("/ManageUsers/GetDataConflictUserStudies", { dataConflictApplicationUserID: dataConflictUserId });
            };
            DataAccessService.prototype.getDataConflictApplicationRoles = function () {
                var roles = this.$resource("/ManageUsers/getApplicationRoles");
                return roles;
            };
            DataAccessService.prototype.saveDataConflictRole = function (dataConflictUserId, dataConflictRoleId, studyIDs) {
                var saveSuccessful = this.$resource("/ManageUsers/SaveDataConflictUserRole", { dataConflictUserId: dataConflictUserId, dataConflictRoleId: dataConflictRoleId, studyIDs: studyIDs });
                return saveSuccessful;
            };
            // --> end of Manage Users
            // Package Conflict Detail
            DataAccessService.prototype.getSelectedPackageSubjectConflict = function (selectedPackageId) {
                var result = this.$resource("/ConflictPackage/GetDataConflictPackageSubjectDetail", { packageId: selectedPackageId });
                return result;
            };
            DataAccessService.prototype.getSelectedPackageVisitConflict = function (selectedPackageId) {
                var result = this.$resource("/ConflictPackage/GetDataConflictPackageVisitDetail", { packageId: selectedPackageId });
                return result;
            };
            DataAccessService.prototype.getSubjectBlindingDetail = function (selectedPackageId) {
                var result = this.$resource("/ConflictPackage/GetDataConflictSubjectBlindingDetail", { packageId: selectedPackageId });
                return result;
            };
            DataAccessService.prototype.getHeaderInfo = function (selectedPackageId, currentUserName) {
                var result = this.$resource("/ConflictPackage/GetHeaderInfo", { packageId: selectedPackageId, userName: currentUserName });
                return result;
            };
            DataAccessService.prototype.getPackageComment = function (selectedPackageId) {
                var result = this.$resource("/ConflictPackage/GetPackageComment", { packageId: selectedPackageId });
                return result;
            };
            DataAccessService.prototype.getSubjectVisitComments = function (selectedPackageId) {
                var result = this.$resource("/ConflictPackage/GetSubjectVisitComments", { packageId: selectedPackageId });
                return result;
            };
            DataAccessService.prototype.getSubjectVisitAttachments = function (selectedPackageId) {
                var result = this.$resource("/ConflictPackage/GetSubjectVisitAttachments", { packageId: selectedPackageId });
                return result;
            };
            DataAccessService.prototype.getSubjectVisitAssessments = function (selectedPackageId) {
                var result = this.$resource("/ConflictPackage/GetSubjectVisitAssessments", { packageId: selectedPackageId });
                return result;
            };
            DataAccessService.prototype.getSubjectVisitInterviewItem = function (selectedPackageId) {
                var result = this.$resource("/ConflictPackage/GetSubjectVisitInterviewItem", { packageId: selectedPackageId });
                return result;
            };
            // --> end of Package Conflict Detail
            // Authentication Detail
            DataAccessService.prototype.authenticateUser = function (SelectedUsername, SelectedPassword) {
                var saveSuccessful = this.$resource("/Authentication/AuthenticateUser", { Username: SelectedUsername, Password: SelectedPassword });
                return saveSuccessful;
            };
            DataAccessService.$inject = ["$resource", "$http"];
            return DataAccessService;
        }());
        common.DataAccessService = DataAccessService;
        angular
            .module("common.services")
            .service("dataAccessService", DataAccessService);
    })(common = app.common || (app.common = {}));
})(app || (app = {}));
//# sourceMappingURL=dataAccessService.js.map