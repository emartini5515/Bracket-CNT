// PackageComment view model
// this will be place holder for the PackageComment returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageComment = (function () {
            function PackageComment(packageComment) {
                this.packageComment = packageComment;
            }
            return PackageComment;
        }());
        domain.PackageComment = PackageComment;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageComment.js.map