// PackageConflictInterviewItemTimeStamps view model
// this will be place holder for the PackageConflictInterviewItemTimeStamps returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictInterviewItemTimeStamps = (function () {
            function PackageConflictInterviewItemTimeStamps() {
            }
            return PackageConflictInterviewItemTimeStamps;
        }());
        domain.PackageConflictInterviewItemTimeStamps = PackageConflictInterviewItemTimeStamps;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictInterviewItemTimeStamps.js.map