// PackageConflictVisit view model
// this will be place holder for the PackageConflictVisit returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictVisit = (function () {
            function PackageConflictVisit() {
            }
            return PackageConflictVisit;
        }());
        domain.PackageConflictVisit = PackageConflictVisit;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictVisit.js.map