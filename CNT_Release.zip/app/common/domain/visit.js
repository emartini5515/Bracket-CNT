// Visit view model
// this will be place holder for the Visit returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var Visit = (function () {
            function Visit(visitId, visitName) {
                this.visitId = visitId;
                this.visitName = visitName;
            }
            return Visit;
        }());
        domain.Visit = Visit;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=visit.js.map