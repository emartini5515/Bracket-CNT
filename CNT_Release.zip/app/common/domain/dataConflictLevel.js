//DataConflictLevels view model
// this will be place holder for the DataConflictLevels returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var DataConflictLevel = (function () {
            function DataConflictLevel(DataConflictLevel, LevelName, IsDeleted) {
                this.DataConflictLevel = DataConflictLevel;
                this.LevelName = LevelName;
                this.IsDeleted = IsDeleted;
            }
            return DataConflictLevel;
        }());
        domain.DataConflictLevel = DataConflictLevel;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=dataConflictLevel.js.map