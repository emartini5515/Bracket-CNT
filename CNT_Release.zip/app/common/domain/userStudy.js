// UserStudy view model
// this will be place holder for the UserStudy returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var UserStudy = (function () {
            function UserStudy(studyID, projectDescription, userHasStudy, partialUploadConfigured) {
                this.studyID = studyID;
                this.projectDescription = projectDescription;
                this.userHasStudy = userHasStudy;
                this.partialUploadConfigured = partialUploadConfigured;
            }
            return UserStudy;
        }());
        domain.UserStudy = UserStudy;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=userStudy.js.map