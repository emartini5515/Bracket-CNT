// PackageConflictSubject view model
// this will be place holder for the PackageConflictSubject returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictSubject = (function () {
            function PackageConflictSubject() {
            }
            return PackageConflictSubject;
        }());
        domain.PackageConflictSubject = PackageConflictSubject;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictSubject.js.map