// SearchPackage view model
// this will be place holder for the SearchPackage returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var SearchPackage = (function () {
            function SearchPackage() {
            }
            return SearchPackage;
        }());
        domain.SearchPackage = SearchPackage;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=searchPackage.js.map