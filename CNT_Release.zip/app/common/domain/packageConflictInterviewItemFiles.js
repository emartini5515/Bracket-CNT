// PackageConflictInterviewItemFiles view model
// this will be place holder for the PackageConflictInterviewItemFiles returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictInterviewItemFiles = (function () {
            function PackageConflictInterviewItemFiles() {
            }
            return PackageConflictInterviewItemFiles;
        }());
        domain.PackageConflictInterviewItemFiles = PackageConflictInterviewItemFiles;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictInterviewItemFiles.js.map