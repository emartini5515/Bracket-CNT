// DataConflictApplicationUser view model
// this will be place holder for the DataConflictApplicationUser returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var DataConflictApplicationUser = (function () {
            function DataConflictApplicationUser(firstName, lastName, username, dataConflictApplicationRoleID, dataConflictApplicationRoleName, dataConflictApplicationUserID) {
                this.firstName = firstName;
                this.lastName = lastName;
                this.username = username;
                this.dataConflictApplicationRoleID = dataConflictApplicationRoleID;
                this.dataConflictApplicationRoleName = dataConflictApplicationRoleName;
                this.dataConflictApplicationUserID = dataConflictApplicationUserID;
            }
            return DataConflictApplicationUser;
        }());
        domain.DataConflictApplicationUser = DataConflictApplicationUser;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=dataConflictApplicationUser.js.map