// PackageConflictInterviewItem view model
// this will be place holder for the PackageConflictInterviewItem returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictInterviewItem = (function () {
            function PackageConflictInterviewItem() {
            }
            return PackageConflictInterviewItem;
        }());
        domain.PackageConflictInterviewItem = PackageConflictInterviewItem;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictInterviewItem.js.map