// PackageConflictInterviewItemComments view model
// this will be place holder for the PackageConflictInterviewItemComments returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictInterviewItemComments = (function () {
            function PackageConflictInterviewItemComments() {
            }
            return PackageConflictInterviewItemComments;
        }());
        domain.PackageConflictInterviewItemComments = PackageConflictInterviewItemComments;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictInterviewItemComments.js.map