// PackageConflictInterviewItemAttachments view model
// this will be place holder for the PackageConflictInterviewItemAttachments returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictInterviewItemAttachments = (function () {
            function PackageConflictInterviewItemAttachments() {
            }
            return PackageConflictInterviewItemAttachments;
        }());
        domain.PackageConflictInterviewItemAttachments = PackageConflictInterviewItemAttachments;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictInterviewItemAttachments.js.map