// this filter will convert true/false to yes/no
var app;
(function (app) {
    var YesOrNo;
    (function (YesOrNo) {
        var YesNoFilter = (function () {
            function YesNoFilter() {
            }
            YesNoFilter.filter = function () {
                return function (input) {
                    var result = "No";
                    if (angular.isUndefined(input) || input === null) {
                    }
                    else {
                        if (input.length === 0) {
                        }
                        else {
                            if ((input + "").toLowerCase() === "true") {
                                result = "Yes";
                            }
                        }
                    }
                    return result;
                };
            };
            return YesNoFilter;
        }());
        YesOrNo.YesNoFilter = YesNoFilter;
    })(YesOrNo = app.YesOrNo || (app.YesOrNo = {}));
})(app || (app = {}));
angular
    .module("dataConflictToolApp")
    .filter("yesOrNo", app.YesOrNo.YesNoFilter.filter);
//# sourceMappingURL=YesOrNo.js.map