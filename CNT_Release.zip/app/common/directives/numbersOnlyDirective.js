//Will limit an input to only numbers, simply ignoring any other keys
var app;
(function (app) {
    var NumbersOnlyDirective;
    (function (NumbersOnlyDirective) {
        function numbersOnlyDirective() {
            return {
                require: 'ngModel',
                restrict: 'A',
                link: function (scope, element, attr, ngModelCtrl) {
                    var l_ngModelCtrl = (Object.prototype.toString.call(ngModelCtrl) === '[object Array]') ? ngModelCtrl[0] : ngModelCtrl;
                    function fromUser(text) {
                        if (text) {
                            var transformedInput = text.replace(/[^0-9]/g, '');
                            if (transformedInput !== text) {
                                l_ngModelCtrl.$setViewValue(transformedInput);
                                l_ngModelCtrl.$render();
                            }
                            return transformedInput;
                        }
                        return undefined;
                    }
                    l_ngModelCtrl.$parsers.push(fromUser);
                }
            };
        }
        NumbersOnlyDirective.numbersOnlyDirective = numbersOnlyDirective;
        angular
            .module("dataConflictToolApp")
            .directive('onlyNumbers', app.NumbersOnlyDirective.numbersOnlyDirective);
    })(NumbersOnlyDirective = app.NumbersOnlyDirective || (app.NumbersOnlyDirective = {}));
})(app || (app = {}));
//# sourceMappingURL=numbersOnlyDirective.js.map