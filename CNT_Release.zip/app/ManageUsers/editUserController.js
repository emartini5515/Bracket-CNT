// this is the controller to handle the edit user in the manage user section
var app;
(function (app) {
    var manageUsersList;
    (function (manageUsersList) {
        var EditUserController = (function () {
            function EditUserController($scope, dataAccessService, dataConflictUser, $uibModalInstance, authenticationService) {
                var _this = this;
                this.$scope = $scope;
                this.dataAccessService = dataAccessService;
                this.dataConflictUser = dataConflictUser;
                this.$uibModalInstance = $uibModalInstance;
                this.authenticationService = authenticationService;
                this.dctUser = dataConflictUser;
                this.dataService = dataAccessService;
                this.authService = authenticationService;
                this.modalInstance = $uibModalInstance;
                var studyResource = this.dataService.getDataConflictApplicationUserStudies(this.dctUser.dataConflictApplicationUserID);
                studyResource.query(function (data) {
                    _this.studiesAssigned = data.filter(function (study) {
                        return study.userHasStudy;
                    });
                    _this.studiesAssigned.sort(_this.sortStudies);
                    _this.studiesUnassigned = data.filter(function (study) {
                        return !study.userHasStudy;
                    });
                    _this.studiesUnassigned.sort(_this.sortStudies);
                    _this.selectedAssignedStudies = [_this.studiesAssigned[0]]; //prevent angular from automatically creating a blank option by defaulting the selection
                    _this.selectedUnassignedStudies = [_this.studiesUnassigned[0]]; //prevent angular from automatically creating a blank option by defaulting the selection
                }, function (data) { console.log("Error: " + data); });
                var roleResource = this.dataService.getDataConflictApplicationRoles();
                roleResource.query(function (data) {
                    _this.applicationRoleList = data;
                }, function (data) { console.log("Error: " + data); });
                this.selectedRoleId = this.dctUser.dataConflictApplicationRoleID;
            }
            EditUserController.prototype.saveUser = function () {
                var newThis = this;
                var studyIDStr = newThis.studiesAssigned.map(function (elem) { return elem.studyID; }).join(",");
                var success = function () {
                    var resource = newThis.dataService.saveDataConflictRole(newThis.dctUser.dataConflictApplicationUserID, newThis.selectedRoleId, studyIDStr);
                    resource.query(function (data) {
                        newThis.modalInstance.close();
                    }, function (error) {
                        console.log("Error saving application role: " + error);
                    });
                };
                this.authenticationService.showAuthentication(success);
            };
            ;
            EditUserController.prototype.cancelSaveUser = function () {
                this.modalInstance.close();
            };
            ;
            EditUserController.prototype.addStudies = function () {
                var lim1 = this.selectedUnassignedStudies.length;
                for (var i = 0; i < lim1; i++) {
                    var studyID = this.selectedUnassignedStudies[i].studyID;
                    var lim2 = this.studiesUnassigned.length;
                    for (var ii = 0; ii < lim2; ii++) {
                        if (this.studiesUnassigned[ii].studyID === studyID) {
                            var study = this.studiesUnassigned.splice(ii, 1)[0];
                            this.studiesAssigned.push(study);
                            break;
                        }
                    }
                }
                this.studiesAssigned.sort(this.sortStudies);
            };
            ;
            EditUserController.prototype.addAllStudies = function () {
                var lim = this.studiesUnassigned.length;
                for (var i = (lim - 1); i > -1; i--) {
                    var study = this.studiesUnassigned.splice(i, 1)[0];
                    this.studiesAssigned.push(study);
                }
                this.studiesAssigned.sort(this.sortStudies);
            };
            ;
            EditUserController.prototype.removeStudies = function () {
                var lim1 = this.selectedAssignedStudies.length;
                for (var i = 0; i < lim1; i++) {
                    var studyID = this.selectedAssignedStudies[i].studyID;
                    var lim2 = this.studiesAssigned.length;
                    for (var ii = 0; ii < lim2; ii++) {
                        if (this.studiesAssigned[ii].studyID === studyID) {
                            var study = this.studiesAssigned.splice(ii, 1)[0];
                            this.studiesUnassigned.push(study);
                            break;
                        }
                    }
                }
                this.studiesUnassigned.sort(this.sortStudies);
            };
            ;
            EditUserController.prototype.removeAllStudies = function () {
                var lim = this.studiesAssigned.length;
                for (var i = (lim - 1); i > -1; i--) {
                    var study = this.studiesAssigned.splice(i, 1)[0];
                    this.studiesUnassigned.push(study);
                }
                this.studiesUnassigned.sort(this.sortStudies);
            };
            ;
            EditUserController.prototype.sortStudies = function (a, b) {
                if (a.projectDescription.trim().toUpperCase() > b.projectDescription.trim().toUpperCase())
                    return 1;
                if (a.projectDescription.trim().toUpperCase() < b.projectDescription.trim().toUpperCase())
                    return -1;
                return 0;
            };
            EditUserController.$inject = ["$scope", "dataAccessService", "dataConflictUser", "$uibModalInstance", "authenticationService"];
            return EditUserController;
        }());
        manageUsersList.EditUserController = EditUserController;
        angular
            .module("dataConflictToolApp") //.module("dataConflictToolApp", ["ui.bootstrap"])
            .controller("EditUserController", EditUserController);
    })(manageUsersList = app.manageUsersList || (app.manageUsersList = {}));
})(app || (app = {}));
//# sourceMappingURL=editUserController.js.map