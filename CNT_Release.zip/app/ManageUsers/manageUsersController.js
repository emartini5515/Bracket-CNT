// this is the controller to handle the manage user landing page
var app;
(function (app) {
    var manageUsersList;
    (function (manageUsersList) {
        var ManageUsersController = (function () {
            function ManageUsersController(dataAccessService, $uibModal, $root) {
                var _this = this;
                this.dataAccessService = dataAccessService;
                this.$uibModal = $uibModal;
                this.updateUserList = function () {
                    this.searchUsers();
                };
                $root["subTitle"] = "Manage Users";
                this.dataService = dataAccessService;
                this.uibModal = $uibModal;
                var roleResource = dataAccessService.getDataConflictApplicationRoles();
                roleResource.query(function (data) {
                    _this.applicationRoleList = data;
                }, function (data) { console.log("Error: " + data); });
            }
            ManageUsersController.prototype.searchUsers = function () {
                var _this = this;
                var userResource = this.dataService.getDataConflictApplicationUsers(this.selectedFirstName, this.selectedLastName, this.selectedApplicationRoleId);
                userResource.query(function (data) {
                    _this.applicationUserList = data;
                }, function (data) { console.log("Error: " + data); });
            };
            ManageUsersController.prototype.editUser = function (dataConflictApplicationUser) {
                var _this = this;
                this.uibModal.open({
                    animation: true,
                    ariaLabelledBy: 'modal-title',
                    ariaDescribedBy: 'modal-body',
                    templateUrl: 'app/manageUsers/editUser.html',
                    controller: 'EditUserController',
                    controllerAs: 'vm',
                    windowClass: 'modal-large',
                    backdrop: 'static',
                    keyboard: false,
                    resolve: {
                        dataConflictUser: dataConflictApplicationUser
                    }
                }).closed.then(function () {
                    _this.updateUserList();
                });
            };
            ManageUsersController.prototype.resetForm = function (form) {
                this.selectedFirstName = null;
                this.selectedLastName = null;
                this.selectedApplicationRoleId = null;
                form.$setPristine();
                form.$setUntouched();
            };
            ManageUsersController.$inject = ["dataAccessService", "$uibModal", "$rootScope"];
            return ManageUsersController;
        }());
        manageUsersList.ManageUsersController = ManageUsersController;
        angular
            .module("dataConflictToolApp")
            .controller("ManageUsersController", ManageUsersController);
    })(manageUsersList = app.manageUsersList || (app.manageUsersList = {}));
})(app || (app = {}));
//# sourceMappingURL=manageUsersController.js.map