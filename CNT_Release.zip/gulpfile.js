﻿var gulp = require('gulp');
var Server = require('karma').Server;
var tslint = require("gulp-tslint");
var ts = require("gulp-typescript");
var karma = require("gulp-karma");

gulp.task('default', function () {
    gulp.run('tslint');
    gulp.run('scripts');
    gulp.run('karmaTest');
});

gulp.task("tslint", function () {
    gulp.src('app/**/*.ts')
        .pipe(tslint({
            formatter: "verbose"
        }))
        .pipe(tslint.report());
});

gulp.task('scripts', function () {
    return gulp.src('app/**/*.ts')
    .pipe(
        ts({
            "compilerOptions": {
                "target": "es5",
                "module": "commonjs",
                "sourceMap": true
            }
        })
    )
    .pipe(gulp.dest(function (file) {
        return file.base;
    }));
});

gulp.task('karmaTest', function (done) {
        new Server({
            configFile: __dirname + '/karma.conf.js',
            singleRun: true
        }, done).start();
    });
gulp.task('watch', ['scripts'], function () {
    gulp.watch('src/**/*.ts', ['scripts']);
});

