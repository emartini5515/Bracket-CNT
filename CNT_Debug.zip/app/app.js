// this is the main angular bootstrap application
// we define the state/URL here along with the breadcrumb info
var app;
(function (app) {
    angular.module("dataConflictToolApp", ["common.services", "ui.bootstrap", "ui.router", "ngSanitize", "ncy-angular-breadcrumb", "blockUI"])
        .config(["$stateProvider", "$urlRouterProvider", "$compileProvider", "$breadcrumbProvider", "$httpProvider",
        function ($stateProvider, $urlRouterProvider, $compileProvider, $breadcrumbProvider, $httpProvider) {
            return new app.MyConfig($stateProvider, $urlRouterProvider, $compileProvider, $breadcrumbProvider, $httpProvider);
        }
    ])
        .run(initState);
    var MyConfig = (function () {
        function MyConfig($stateProvider, $urlRouterProvider, $compileProvider, $breadcrumbProvider, $httpProvider) {
            this.$stateProvider = $stateProvider;
            this.$urlRouterProvider = $urlRouterProvider;
            this.$compileProvider = $compileProvider;
            this.$breadcrumbProvider = $breadcrumbProvider;
            this.$httpProvider = $httpProvider;
            this.init();
            this.removeCache($httpProvider);
            $compileProvider.debugInfoEnabled(true);
            $urlRouterProvider.otherwise("home");
            $breadcrumbProvider.setOptions({
                prefixStateName: 'home',
                //template: 'bootstrap3'
                templateUrl: 'app/templates/breadcrumb.html'
            });
        }
        MyConfig.prototype.removeCache = function ($httpProvider) {
            //this is needed so that Internet Explorer will refresh data grid after data reload / update in angular
            if (!$httpProvider.defaults.headers.get) {
                $httpProvider.defaults.headers.get = {};
            }
            $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
            $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
            $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
        };
        MyConfig.prototype.init = function () {
            this.$stateProvider.state("home", {
                url: "/",
                templateUrl: "app/subjectVisit/subjectVisit.html",
                controller: "SubjectVisitController",
                controllerAs: "vm",
                ncyBreadcrumb: {
                    label: 'Search Data Conflicts'
                }
            });
            this.$stateProvider.state("compare", {
                url: "/compare/:packageId",
                templateUrl: "app/compare/compare.html",
                controller: "PackageConflictController",
                controllerAs: "vm",
                ncyBreadcrumb: {
                    label: 'Manage Subject Visit'
                }
            });
            this.$stateProvider.state("interviewItemDetail", {
                url: "/interviewItemDetail/:packageId/:interviewItemId",
                templateUrl: "app/interviewItem/interviewItem.html",
                controller: "interviewItemController",
                controllerAs: "vm",
                ncyBreadcrumb: {
                    label: 'Manage Interview Item',
                    parent: 'compare'
                }
            });
            this.$stateProvider.state("manageUsers", {
                url: "/manageUsers",
                templateUrl: "app/ManageUsers/manageUsers.html",
                controller: "ManageUsersController",
                controllerAs: "vm",
                ncyBreadcrumb: {
                    label: 'Manage Users'
                }
            });
            this.$stateProvider.state("editUser", {
                url: "/editUser",
                templateUrl: "app/ManageUsers/editUser.html",
                controller: "EditUserController",
                controllerAs: "vm"
            });
            this.$stateProvider.state("reprocessedPackages", {
                url: "/reprocessedPackages",
                templateUrl: "app/subjectVisit/reprocessedPackages.html",
                controller: "ReprocessedPackagesController",
                controllerAs: "vm"
            });
        };
        return MyConfig;
    }());
    app.MyConfig = MyConfig;
})(app || (app = {}));
function initState($state, $rootScope, $window) {
    $rootScope["title"] = 'Data Conflict Tool';
    $rootScope["subTitle"] = "";
    $rootScope.$on("$stateChangeSuccess", function (event, currentState, previousState) {
        $window.scrollTo(0, 0);
    });
    $state.go("home");
}
//# sourceMappingURL=app.js.map