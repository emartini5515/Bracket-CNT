// this is the authentication service to be injected into a module
var app;
(function (app) {
    var common;
    (function (common) {
        var AuthenticationService = (function () {
            function AuthenticationService($uibModal) {
                this.$uibModal = $uibModal;
                this.uibModal = $uibModal;
            }
            AuthenticationService.prototype.showAuthentication = function (success, message) {
                this.uibModal.open({
                    animation: true,
                    ariaLabelledBy: "modal-title",
                    ariaDescribedBy: "modal-body",
                    templateUrl: "app/common/services/authentication.html",
                    controller: "AuthenticationController",
                    controllerAs: "vm",
                    backdrop: "static",
                    keyboard: false,
                    resolve: {
                        successCallback: function () { return success; },
                        displayMessage: function () { return message; }
                    }
                }).rendered.then(function () {
                    //TFS 61100 Focus is set on this textbox automatically but while the uibModal animation is occurring, misaligning the cursor slightly until mouseover in IE.
                    //So either we eliminate the animation, or re-set the focus manually after the dialog has had a chance to complete. BobHering 30Mar2017
                    setTimeout(function () { $('#textboxUsername').focus(); }, 500);
                });
                ;
            };
            ;
            AuthenticationService.$inject = ["$uibModal"];
            return AuthenticationService;
        }());
        common.AuthenticationService = AuthenticationService;
        angular
            .module("common.services")
            .service("authenticationService", AuthenticationService);
    })(common = app.common || (app.common = {}));
})(app || (app = {}));
//# sourceMappingURL=authenticationService.js.map