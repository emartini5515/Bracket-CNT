// this is an angular filter to filter the study content in the search page
var app;
(function (app) {
    var filters;
    (function (filters) {
        function FilterStudies() {
            return function (items, limitToAssigned) {
                var filtered = [];
                if (!limitToAssigned) {
                    return items;
                }
                angular.forEach(items, function (item) {
                    if (item.userHasStudy) {
                        filtered.push(item);
                    }
                });
                return filtered;
            };
        }
        filters.FilterStudies = FilterStudies;
        angular.module("dataConflictToolApp").filter("filterStudies", FilterStudies);
    })(filters = app.filters || (app.filters = {}));
})(app || (app = {}));
//# sourceMappingURL=filterStudies.js.map