// this a utility filter to allow unsafe/raw HTML in the view
var app;
(function (app) {
    var Unsafe;
    (function (Unsafe) {
        var TrustResource = (function () {
            function TrustResource() {
            }
            TrustResource.filter = function ($sce) {
                return function (value) {
                    return $sce.trustAsHtml(value);
                };
            };
            TrustResource.$inject = ["$sce"];
            return TrustResource;
        }());
        Unsafe.TrustResource = TrustResource;
    })(Unsafe = app.Unsafe || (app.Unsafe = {}));
})(app || (app = {}));
angular
    .module("dataConflictToolApp")
    .filter("unsafe", app.Unsafe.TrustResource.filter);
//# sourceMappingURL=unsafe.js.map