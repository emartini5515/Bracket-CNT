// header directive to specify custom tag in the main page, _layout.cshtml
var app;
(function (app) {
    var HeaderDirective;
    (function (HeaderDirective) {
        function headerDirective() {
            return {
                controller: "headerController",
                controllerAs: 'vm',
                templateUrl: "app/header/header.html"
            };
        }
        HeaderDirective.headerDirective = headerDirective;
        angular
            .module("dataConflictToolApp")
            .directive("webHeader", app.HeaderDirective.headerDirective);
    })(HeaderDirective = app.HeaderDirective || (app.HeaderDirective = {}));
})(app || (app = {}));
//# sourceMappingURL=headerDirective.js.map