// Study view model
// this will be place holder for the Study returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var Study = (function () {
            function Study(studyId, studyName, userHasStudy, partialUploadConfigured) {
                this.studyId = studyId;
                this.studyName = studyName;
                this.userHasStudy = userHasStudy;
                this.partialUploadConfigured = partialUploadConfigured;
            }
            return Study;
        }());
        domain.Study = Study;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=study.js.map