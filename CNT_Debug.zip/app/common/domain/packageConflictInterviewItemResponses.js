// PackageConflictInterviewItemResponses view model
// this will be place holder for the PackageConflictInterviewItemResponses returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictInterviewItemResponses = (function () {
            function PackageConflictInterviewItemResponses() {
            }
            return PackageConflictInterviewItemResponses;
        }());
        domain.PackageConflictInterviewItemResponses = PackageConflictInterviewItemResponses;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictInterviewItemResponses.js.map