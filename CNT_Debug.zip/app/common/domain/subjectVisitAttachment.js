// SubjectVisitAttachment view model
// this will be place holder for the SubjectVisitAttachment returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var SubjectVisitAttachment = (function () {
            function SubjectVisitAttachment(packageID, pK_OverallBlockStatus, pK_IndividualAttachmentStatus, pK_AttachmentDate, pK_AttachmentType, pK_DocumentReceivedDate, pK_DocumentType, pK_DocumentStatus, pK_DocumentDescription, pK_Language, pK_CountryID, pK_OriginalDocumentName) {
                this.packageID = packageID;
                this.pK_OverallBlockStatus = pK_OverallBlockStatus;
                this.pK_IndividualAttachmentStatus = pK_IndividualAttachmentStatus;
                this.pK_AttachmentDate = pK_AttachmentDate;
                this.pK_AttachmentType = pK_AttachmentType;
                this.pK_DocumentReceivedDate = pK_DocumentReceivedDate;
                this.pK_DocumentType = pK_DocumentType;
                this.pK_DocumentStatus = pK_DocumentStatus;
                this.pK_DocumentDescription = pK_DocumentDescription;
                this.pK_Language = pK_Language;
                this.pK_CountryID = pK_CountryID;
                this.pK_OriginalDocumentName = pK_OriginalDocumentName;
            }
            return SubjectVisitAttachment;
        }());
        domain.SubjectVisitAttachment = SubjectVisitAttachment;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=subjectVisitAttachment.js.map