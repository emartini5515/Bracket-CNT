// Site view model
// this will be place holder for the Site returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var Site = (function () {
            function Site(siteId, siteName) {
                this.siteId = siteId;
                this.siteName = siteName;
            }
            return Site;
        }());
        domain.Site = Site;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=site.js.map