// PackageConflictInterviewItemTotals view model
// this will be place holder for the PackageConflictInterviewItemTotals returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictInterviewItemTotals = (function () {
            function PackageConflictInterviewItemTotals() {
            }
            return PackageConflictInterviewItemTotals;
        }());
        domain.PackageConflictInterviewItemTotals = PackageConflictInterviewItemTotals;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictInterviewItemTotals.js.map