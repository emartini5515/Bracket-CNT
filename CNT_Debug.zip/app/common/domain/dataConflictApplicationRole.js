// DataConflictApplicationRole view model
// this will be place holder for the DataConflictApplicationRole returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var DataConflictApplicationRole = (function () {
            function DataConflictApplicationRole(dataConflictApplicationRoleID, applicationRoleName, applicationRoleInternalName) {
                this.dataConflictApplicationRoleID = dataConflictApplicationRoleID;
                this.applicationRoleName = applicationRoleName;
                this.applicationRoleInternalName = applicationRoleInternalName;
            }
            return DataConflictApplicationRole;
        }());
        domain.DataConflictApplicationRole = DataConflictApplicationRole;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=dataConflictApplicationRole.js.map