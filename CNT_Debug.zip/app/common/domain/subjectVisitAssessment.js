// SubjectVisitAssessment view model
// this will be place holder for the SubjectVisitAssessment returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var SubjectVisitAssessment = (function () {
            function SubjectVisitAssessment(packageID, assessmentDate, rater, scales, assignedTo, completedBy) {
                this.packageID = packageID;
                this.assessmentDate = assessmentDate;
                this.rater = rater;
                this.scales = scales;
                this.assignedTo = assignedTo;
                this.completedBy = completedBy;
            }
            return SubjectVisitAssessment;
        }());
        domain.SubjectVisitAssessment = SubjectVisitAssessment;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=subjectVisitAssessment.js.map