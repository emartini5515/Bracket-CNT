// country view model
// this will be place holder for the countries returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var Country = (function () {
            function Country(countryId, countryName) {
                this.countryId = countryId;
                this.countryName = countryName;
            }
            return Country;
        }());
        domain.Country = Country;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=country.js.map