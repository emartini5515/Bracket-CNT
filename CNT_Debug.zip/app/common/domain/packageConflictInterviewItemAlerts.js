// PackageConflictInterviewItemAlerts view model
// this will be place holder for the PackageConflictInterviewItemAlerts returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var PackageConflictInterviewItemAlerts = (function () {
            function PackageConflictInterviewItemAlerts() {
            }
            return PackageConflictInterviewItemAlerts;
        }());
        domain.PackageConflictInterviewItemAlerts = PackageConflictInterviewItemAlerts;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictInterviewItemAlerts.js.map