// SubjectVisitInterviewItem view model
// this will be place holder for the SubjectVisitInterviewItem returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var SubjectVisitInterviewItem = (function () {
            function SubjectVisitInterviewItem(packageID, interviewItemName, interviewItemID, pK_IsPending, pK_SubjectVisitInterviewItemID, pK_InterviewItemExists, rS_InterviewItemExists, conflictStatus) {
                this.packageID = packageID;
                this.interviewItemName = interviewItemName;
                this.interviewItemID = interviewItemID;
                this.pK_IsPending = pK_IsPending;
                this.pK_SubjectVisitInterviewItemID = pK_SubjectVisitInterviewItemID;
                this.pK_InterviewItemExists = pK_InterviewItemExists;
                this.rS_InterviewItemExists = rS_InterviewItemExists;
                this.conflictStatus = conflictStatus;
            }
            return SubjectVisitInterviewItem;
        }());
        domain.SubjectVisitInterviewItem = SubjectVisitInterviewItem;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=subjectVisitInterviewItem.js.map