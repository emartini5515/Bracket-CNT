// StudyProtocol view model
// this will be place holder for the StudyProtocol returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var StudyProtocol = (function () {
            function StudyProtocol(studyProtocolId, studyProtocolName) {
                this.studyProtocolId = studyProtocolId;
                this.studyProtocolName = studyProtocolName;
            }
            return StudyProtocol;
        }());
        domain.StudyProtocol = StudyProtocol;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=studyProtocol.js.map