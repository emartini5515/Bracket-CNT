// HeaderInfo view model
// this will be place holder for the HeaderInfo returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var HeaderInfo = (function () {
            function HeaderInfo(visitName, sponsorSubjectID, protocolName, projectCode, projectDescription, userHasStudyConfigured, comment) {
                this.visitName = visitName;
                this.sponsorSubjectID = sponsorSubjectID;
                this.protocolName = protocolName;
                this.projectCode = projectCode;
                this.projectDescription = projectDescription;
                this.userHasStudyConfigured = userHasStudyConfigured;
                this.comment = comment;
            }
            return HeaderInfo;
        }());
        domain.HeaderInfo = HeaderInfo;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=headerInfo.js.map