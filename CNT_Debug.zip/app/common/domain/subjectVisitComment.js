// SubjectVisitComment view model
// this will be place holder for the SubjectVisitComment returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var SubjectVisitComment = (function () {
            function SubjectVisitComment(packageID, pK_OverallBlockStatus, pK_CommentText, pK_CommentType, pK_CreatedBy) {
                this.packageID = packageID;
                this.pK_OverallBlockStatus = pK_OverallBlockStatus;
                this.pK_CommentText = pK_CommentText;
                this.pK_CommentType = pK_CommentType;
                this.pK_CreatedBy = pK_CreatedBy;
            }
            return SubjectVisitComment;
        }());
        domain.SubjectVisitComment = SubjectVisitComment;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=subjectVisitComment.js.map