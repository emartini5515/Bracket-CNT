// SubjectVisitSearch view model
// this will be place holder for the SubjectVisitSearch returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var SubjectVisitSearch = (function () {
            function SubjectVisitSearch(packageID, StudyID, ProjectDescription, SubjectID, SponsorSubjectID, SponsorSiteID, ProtocolName, RDASiteID, SubjectVisitID, VisitName, VisitDate, VisitStatusType, FlagsExist, MaskedVisitRandomOrder, VisitID, VisitNumber, CountryName, SubjectLanguage, SponsorSiteIDPI, VisitCountForSubject, VisitDateForSorting, StudyProtocolID, VisitDateString, PartialVisit, PackageDateTime, reprocess) {
                this.packageID = packageID;
                this.StudyID = StudyID;
                this.ProjectDescription = ProjectDescription;
                this.SubjectID = SubjectID;
                this.SponsorSubjectID = SponsorSubjectID;
                this.SponsorSiteID = SponsorSiteID;
                this.ProtocolName = ProtocolName;
                this.RDASiteID = RDASiteID;
                this.SubjectVisitID = SubjectVisitID;
                this.VisitName = VisitName;
                this.VisitDate = VisitDate;
                this.VisitStatusType = VisitStatusType;
                this.FlagsExist = FlagsExist;
                this.MaskedVisitRandomOrder = MaskedVisitRandomOrder;
                this.VisitID = VisitID;
                this.VisitNumber = VisitNumber;
                this.CountryName = CountryName;
                this.SubjectLanguage = SubjectLanguage;
                this.SponsorSiteIDPI = SponsorSiteIDPI;
                this.VisitCountForSubject = VisitCountForSubject;
                this.VisitDateForSorting = VisitDateForSorting;
                this.StudyProtocolID = StudyProtocolID;
                this.VisitDateString = VisitDateString;
                this.PartialVisit = PartialVisit;
                this.PackageDateTime = PackageDateTime;
                this.reprocess = reprocess;
                this.reprocess = false;
            }
            return SubjectVisitSearch;
        }());
        domain.SubjectVisitSearch = SubjectVisitSearch;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=subjectVisitSearch.js.map