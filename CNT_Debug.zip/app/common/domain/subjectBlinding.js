// SubjectBlinding view model
// this will be place holder for the SubjectBlinding returned back from the MVC controller
var app;
(function (app) {
    var domain;
    (function (domain) {
        var SubjectBlinding = (function () {
            function SubjectBlinding(username, rdaSiteID, rdaRaterID, sponsorSubjectID, override, overrideReason, source, packageRecordInternalStatus) {
                this.username = username;
                this.rdaSiteID = rdaSiteID;
                this.rdaRaterID = rdaRaterID;
                this.sponsorSubjectID = sponsorSubjectID;
                this.override = override;
                this.overrideReason = overrideReason;
                this.source = source;
                this.packageRecordInternalStatus = packageRecordInternalStatus;
            }
            return SubjectBlinding;
        }());
        domain.SubjectBlinding = SubjectBlinding;
    })(domain = app.domain || (app.domain = {}));
})(app || (app = {}));
//# sourceMappingURL=subjectBlinding.js.map