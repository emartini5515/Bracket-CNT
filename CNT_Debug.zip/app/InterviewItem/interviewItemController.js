// this is the controller to handle the interview item level conflict
var app;
(function (app) {
    var InterviewItemList;
    (function (InterviewItemList) {
        var InterviewItemController = (function () {
            function InterviewItemController(dataAccessService, $state, $root, $stateParams, authenticationService, sharedProperties, $uibModalInstance) {
                var _this = this;
                this.dataAccessService = dataAccessService;
                this.authenticationService = authenticationService;
                this.sharedProperties = sharedProperties;
                this.$uibModalInstance = $uibModalInstance;
                this.saveSelection = function (selectedAction) {
                    var interviewItemResource = _this.dataService
                        .validateDataConflictOnSave(_this.packageId, _this.interviewItemId, selectedAction, undefined, undefined, undefined, undefined, undefined);
                    interviewItemResource.query(function (data) {
                        var message = "";
                        if (data[0] != undefined)
                            message = data[0].replace(/\[/g, "").replace(/\]/g, "").replace(/\"/g, "").replace(/\,/g, "<br>");
                        if (message == "Nothing Pending") {
                            message =
                                "All conflicts have been resolved. " +
                                    "The data will now be finalized in Rater Station according to the options you selected, " +
                                    "and this conflict will no longer appear in the Data Conflict Tool";
                            _this.targetLocation = "home";
                        }
                        else {
                            _this.targetLocation = "compare";
                            message = "<br>There are still unresolved conflicts in the following areas: <br>" + message;
                        }
                        _this.saveValidationResult = message;
                        _this.authenticateProcess();
                    }, function (data) { console.log("Error: " + data); });
                };
                this.authenticateProcess = function () {
                    var success = function () {
                        var resource = _this.dataService.saveDataConflictStatusInterviewItem(_this.packageId, _this.interviewItemId, _this.packageSelectedAction, _this.currentUser);
                        resource.query(function (data) {
                            //console.log(data);
                            _this.state.go(_this.targetLocation, { packageId: _this.packageId });
                        }, function (error) {
                            console.log("Error saving interview item: " + error);
                        });
                    };
                    _this.authenticationService.showAuthentication(success, _this.saveValidationResult);
                };
                $root["subTitle"] = "Manage Interview Item";
                this.modalInstance = $uibModalInstance;
                this.dataService = dataAccessService;
                this.packageId = $stateParams.packageId;
                this.interviewItemId = $stateParams.interviewItemId;
                this.state = $state;
                this.currentUser = $("#headerView").data("currentuser");
                var headerInfoResource = dataAccessService.getHeaderInfo(this.packageId, this.currentUser);
                headerInfoResource.get(function (data) {
                    _this.headerInfo = data;
                }, function (data) { console.log("Error: " + data); });
                this.populateInterviewItem();
            }
            InterviewItemController.prototype.populateInterviewItem = function () {
                this.loadInterviewItemDetail();
                this.loadInterviewItemResponses();
                this.loadInterviewItemTotals();
                this.loadInterviewItemTimeStamps();
                this.loadInterviewItemTimeAlerts();
                this.loadInterviewItemTimeComments();
                this.loadInterviewItemTimeAttachments();
                this.loadInterviewItemTimeFiles();
            };
            InterviewItemController.prototype.loadInterviewItemDetail = function () {
                var _this = this;
                var interviewItemResource = this.dataService.getDataConflictInterviewItemDetail(this.packageId, this.interviewItemId);
                interviewItemResource.get(function (data) {
                    _this.packageConflictInterviewItemDetail = data;
                    if (data != undefined)
                        _this.packageSelectedAction = data.pK_OverallBlockStatus;
                }, function (data) { console.log("Error: " + data); });
            };
            InterviewItemController.prototype.loadInterviewItemResponses = function () {
                var _this = this;
                var interviewItemResource = this.dataService.getDataConflictInterviewItemResponses(this.packageId, this.interviewItemId);
                interviewItemResource.query(function (data) {
                    _this.packageConflictInterviewItemResponses = data;
                }, function (data) { console.log("Error: " + data); });
            };
            InterviewItemController.prototype.loadInterviewItemTotals = function () {
                var _this = this;
                var interviewItemResource = this.dataService.getDataConflictInterviewItemTotals(this.packageId, this.interviewItemId);
                interviewItemResource.query(function (data) {
                    _this.packageConflictInterviewItemTotals = data;
                }, function (data) { console.log("Error: " + data); });
            };
            InterviewItemController.prototype.loadInterviewItemTimeStamps = function () {
                var _this = this;
                var interviewItemResource = this.dataService.getDataConflictInterviewItemTimeStamps(this.packageId, this.interviewItemId);
                interviewItemResource.query(function (data) {
                    _this.packageConflictInterviewItemTimeStamps = data;
                }, function (data) { console.log("Error: " + data); });
            };
            InterviewItemController.prototype.loadInterviewItemTimeAlerts = function () {
                var _this = this;
                var interviewItemResource = this.dataService.getDataConflictInterviewItemAlerts(this.packageId, this.interviewItemId);
                interviewItemResource.query(function (data) {
                    _this.packageConflictInterviewItemAlerts = data;
                }, function (data) { console.log("Error: " + data); });
            };
            InterviewItemController.prototype.loadInterviewItemTimeComments = function () {
                var _this = this;
                var interviewItemResource = this.dataService.getDataConflictInterviewItemComments(this.packageId, this.interviewItemId);
                interviewItemResource.query(function (data) {
                    _this.packageConflictInterviewItemComments = data;
                }, function (data) { console.log("Error: " + data); });
            };
            InterviewItemController.prototype.loadInterviewItemTimeAttachments = function () {
                var _this = this;
                var interviewItemResource = this.dataService.getDataConflictInterviewItemAttachments(this.packageId, this.interviewItemId);
                interviewItemResource.query(function (data) {
                    _this.packageConflictInterviewItemAttachments = data;
                }, function (data) { console.log("Error: " + data); });
            };
            InterviewItemController.prototype.loadInterviewItemTimeFiles = function () {
                var _this = this;
                var interviewItemResource = this.dataService.getDataConflictInterviewItemFiles(this.packageId, this.interviewItemId);
                interviewItemResource.query(function (data) {
                    _this.packageConflictInterviewItemFiles = data;
                }, function (data) { console.log("Error: " + data); });
            };
            InterviewItemController.prototype.goBackToComparePage = function () {
                this.state.go("compare", { packageId: this.packageId });
            };
            InterviewItemController.$inject = ["dataAccessService", "$state", "$rootScope", "$stateParams", "authenticationService", "sharedProperties", "$uibModal"];
            return InterviewItemController;
        }());
        InterviewItemList.InterviewItemController = InterviewItemController;
        angular
            .module("dataConflictToolApp")
            .controller("interviewItemController", InterviewItemController);
    })(InterviewItemList = app.InterviewItemList || (app.InterviewItemList = {}));
})(app || (app = {}));
//# sourceMappingURL=interviewItemController.js.map