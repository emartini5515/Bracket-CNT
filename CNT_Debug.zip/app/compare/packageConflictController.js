// this is the controller to handle subject level conflict along with loading its data
var app;
(function (app) {
    var packageConflict;
    (function (packageConflict) {
        var PackageConflictController = (function () {
            function PackageConflictController(dataAccessService, sharedProperties, $state, $root, $stateParams, authenticationService) {
                var _this = this;
                this.dataAccessService = dataAccessService;
                this.sharedProperties = sharedProperties;
                this.authenticationService = authenticationService;
                this.authenticateProcess = function () {
                    var success = function () {
                        var resource = _this.dataAccessService.saveDataConflictStatusSubjectVisit(_this.packageId, _this.subjectAction, _this.visitAction, _this.blindedRaterAction, _this.commentsAction, _this.attachmentsAction, _this.headerInfo.comment, _this.currentUser);
                        resource.query(function (data) {
                            _this.state.go(_this.targetLocation, { packageId: _this.packageId });
                        }, function (error) {
                            console.log("Error saving interview item: " + error);
                        });
                    };
                    _this.authenticationService.showAuthentication(success, _this.saveValidationResult);
                };
                $root["subTitle"] = "Manage Subject Visit";
                this.state = $state;
                this.currentUser = $("#headerView").data("currentuser");
                this.packageConflictSubjectListState = false;
                this.packageConflictVisitListState = false;
                this.packageId = $stateParams.packageId;
                var packageConflictSubjectResource = dataAccessService.getSelectedPackageSubjectConflict(this.packageId);
                packageConflictSubjectResource.get(function (data) {
                    _this.packageConflictSubjectList = data;
                    if (data != undefined)
                        _this.subjectAction = data.pK_OverallBlockStatus;
                }, function (data) { console.log("Error: " + data); });
                var packageConflictVisitResource = dataAccessService.getSelectedPackageVisitConflict(this.packageId);
                packageConflictVisitResource.get(function (data) {
                    _this.packageConflictVisitList = data;
                    if (data != undefined)
                        _this.visitAction = data.pK_OverallBlockStatus;
                }, function (data) { console.log("Error: " + data); });
                var subjectBlindingResource = dataAccessService.getSubjectBlindingDetail(this.packageId);
                subjectBlindingResource.query(function (data) {
                    _this.subjectBlindingList = data;
                    if (data[0] != undefined)
                        _this.blindedRaterAction = data[0].packageRecordInternalStatus;
                }, function (data) { console.log("Error: " + data); });
                var headerInfoResource = dataAccessService.getHeaderInfo(this.packageId, this.currentUser);
                headerInfoResource.get(function (data) {
                    _this.headerInfo = data;
                }, function (data) { console.log("Error: " + data); });
                var commentsResource = dataAccessService.getSubjectVisitComments(this.packageId);
                commentsResource.query(function (data) {
                    _this.subjectVisitCommentList = data;
                    if (data[0] != undefined)
                        _this.commentsAction = data[0].pK_OverallBlockStatus;
                }, function (data) { console.log("Error: " + data); });
                var attachmentsResource = dataAccessService.getSubjectVisitAttachments(this.packageId);
                attachmentsResource.query(function (data) {
                    _this.subjectVisitAttachmentList = data;
                    if (data[0] != undefined)
                        _this.attachmentsAction = data[0].pK_OverallBlockStatus;
                }, function (data) { console.log("Error: " + data); });
                var assessmentsResource = dataAccessService.getSubjectVisitAssessments(this.packageId);
                assessmentsResource.query(function (data) {
                    _this.subjectVisitAssessmentList = data;
                }, function (data) { console.log("Error: " + data); });
                var interviewItemResource = dataAccessService.getSubjectVisitInterviewItem(this.packageId);
                interviewItemResource.query(function (data) {
                    _this.subjectVisitInterviewItemList = data;
                }, function (data) { console.log("Error: " + data); });
            }
            PackageConflictController.prototype.getMoreInfo = function (packageId, interviewItemId) {
                this.state.go("interviewItemDetail", { packageId: packageId, interviewItemId: interviewItemId });
            };
            PackageConflictController.prototype.goBackToSearchMenu = function () {
                this.state.go("home");
            };
            PackageConflictController.prototype.saveAndUpdate = function () {
                var _this = this;
                var interviewItemResource = this.dataAccessService
                    .validateDataConflictOnSave(this.packageId, 0, undefined, this.subjectAction, this.visitAction, this.blindedRaterAction, this.commentsAction, this.attachmentsAction);
                interviewItemResource.query(function (data) {
                    //console.log(data);
                    var message = "";
                    if (data[0] != undefined)
                        message = data[0].replace(/\[/g, "").replace(/\]/g, "").replace(/\"/g, "").replace(/\,/g, "<br>");
                    if (message == "Nothing Pending") {
                        message =
                            "All conflicts have been resolved. " +
                                "The data will now be finalized in Rater Station according to the options you selected, " +
                                "and this conflict will no longer appear in the Data Conflict Tool";
                        _this.targetLocation = "home";
                    }
                    else {
                        _this.targetLocation = "compare";
                        message = "<br>There are still unresolved conflicts in the following areas: <br>" + message;
                    }
                    _this.saveValidationResult = message;
                    _this.authenticateProcess();
                }, function (data) { console.log("Error: " + data); });
            };
            PackageConflictController.$inject = ["dataAccessService", "sharedProperties", "$state", "$rootScope", "$stateParams", "authenticationService"];
            return PackageConflictController;
        }());
        packageConflict.PackageConflictController = PackageConflictController;
        angular
            .module("dataConflictToolApp")
            .controller("PackageConflictController", PackageConflictController);
    })(packageConflict = app.packageConflict || (app.packageConflict = {}));
})(app || (app = {}));
//# sourceMappingURL=packageConflictController.js.map