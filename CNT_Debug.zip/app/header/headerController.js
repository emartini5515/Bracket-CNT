// this is the controller for the heading section
var app;
(function (app) {
    var HeaderController;
    (function (HeaderController_1) {
        var HeaderController = (function () {
            function HeaderController(sharedProperties, $scope, $rootScope) {
                this.sharedProperties = sharedProperties;
                $scope.$watch("$root.title", function () {
                    this.title = $rootScope["title"];
                });
                $scope.$watch("$root.subTitle", function () {
                    this.subTitle = $rootScope["subTitle"];
                });
            }
            HeaderController.$inject = ["sharedProperties", "$scope", "$rootScope"];
            return HeaderController;
        }());
        HeaderController_1.HeaderController = HeaderController;
        angular
            .module("dataConflictToolApp")
            .controller("headerController", HeaderController);
    })(HeaderController = app.HeaderController || (app.HeaderController = {}));
})(app || (app = {}));
//# sourceMappingURL=headerController.js.map