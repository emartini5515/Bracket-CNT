// client side unit testing with jasmine
describe('Jasmine internal consistency check', function () {
    it('should equal true', function () {
        expect(true).toBeTruthy();
    });
});
describe('Test Data Conflict Tool App', function () {
    var $controllerConstructor;
    var scope;
    beforeEach(function () {
        angular.mock.module('dataConflictToolApp');
    });
    var dctTitle = "Data Conflict Tool";
    var dctTestUsername = "Clinician.External";
    beforeEach(inject(function ($controller, $rootScope) {
        $controllerConstructor = $controller;
        scope = $rootScope.$new();
    }));
    // todo: working on data access service testing
    //describe('data access service test', () => {
    //    //test the result of a returned promise        
    //    it('should called the API for getStudyResource', inject(function (dataAccessService: app.common.DataAccessService, $rootScope: ng.IRootScopeService,
    //        $httpBackend: ng.IHttpBackendService, $resource: ng.resource.IResourceService) {
    //        $httpBackend.whenGET("/SubjectVisitSearch/getAllStudies").respond({ studyId: 1, studyName: "Test Study" });
    //        $httpBackend.whenGET("app/subjectVisit/subjectVisit.html").respond(function (method, url, data) {
    //            return $resource("app/subjectVisit/subjectVisit.html").get();
    //        });
    //        var result = dataAccessService.getStudyResource().get();
    //        console.log(result);
    //        $rootScope.$digest();
    //        expect(result.valueOf()).toBe(0);
    //    }));
    //});
    //describe('=> Data Access Service',
    //    () => {
    //        it('should have method getStudyResource',
    //            inject(function (dataAccessService: app.common.DataAccessService, $rootScope: ng.IRootScopeService,
    //                        $httpBackend: ng.IHttpBackendService, $resource: ng.resource.IResourceService) {
    //                var result = dataAccessService.getStudyResource().get();
    //                expect(result.$promise).toBeGreaterThan(0);
    //                console.log(result.$promise);
    //            }));
    //    });
    describe('=> Subject Visit Controller', function () {
        it('should have title = "Data Conflict Tool"', function () {
            var ctrl = $controllerConstructor('SubjectVisitController', { $scope: scope });
            expect(ctrl.title).toBe(dctTitle);
        });
        it('should have username = "Clinician.External"', function () {
            var ctrl = $controllerConstructor('SubjectVisitController', { $scope: scope });
            expect(ctrl.username).toBe(dctTestUsername);
        });
        it('should have DataAccess service defined', function () {
            expect(app.common.DataAccessService).toBeDefined();
        });
        it('should have called loadStudyDropdownList', function () {
            var ctrl = $controllerConstructor('SubjectVisitController', { $scope: scope });
            var spy = spyOn(ctrl, 'loadStudyDropdownList');
            ctrl.selectedStudy = 105;
            var tmp = ctrl.loadStudyDropdownList();
            expect(spy).toHaveBeenCalled();
            console.log(tmp);
            console.log(ctrl.selectedStudy);
            expect(typeof ctrl.loadStudyDropdownList).toBe("function");
        });
        it('should have called loadCountryDropdownList', function () {
            var ctrl = $controllerConstructor('SubjectVisitController', { $scope: scope });
            var spy = spyOn(ctrl, 'loadCountryDropdownList');
            ctrl.loadCountryDropdownList();
            expect(spy).toHaveBeenCalled();
            expect(typeof ctrl.loadCountryDropdownList).toBe("function");
        });
        it('should have called loadProtocolDropdownList', function () {
            var ctrl = $controllerConstructor('SubjectVisitController', { $scope: scope });
            var spy = spyOn(ctrl, 'loadProtocolDropdownList');
            ctrl.loadProtocolDropdownList();
            expect(spy).toHaveBeenCalled();
            expect(typeof ctrl.loadProtocolDropdownList).toBe("function");
        });
        it('should have called loadSiteDropdownList', function () {
            var ctrl = $controllerConstructor('SubjectVisitController', { $scope: scope });
            var spy = spyOn(ctrl, 'loadSiteDropdownList');
            ctrl.loadSiteDropdownList();
            expect(spy).toHaveBeenCalled();
            expect(typeof ctrl.loadSiteDropdownList).toBe("function");
        });
        it('should have called loadVisitDropdownList', function () {
            var ctrl = $controllerConstructor('SubjectVisitController', { $scope: scope });
            var spy = spyOn(ctrl, 'loadVisitDropdownList');
            var tmp = ctrl.loadVisitDropdownList();
            expect(spy).toHaveBeenCalled();
            console.log(ctrl.loadVisitDropdownList());
            expect(typeof ctrl.loadVisitDropdownList).toBe("function");
        });
        it('should have called searchSubjectVisit', function () {
            var ctrl = $controllerConstructor('SubjectVisitController', { $scope: scope });
            var spy = spyOn(ctrl, 'searchSubjectVisit');
            ctrl.searchSubjectVisit();
            expect(spy).toHaveBeenCalled();
            expect(typeof ctrl.searchSubjectVisit).toBe("function");
        });
    });
});
//# sourceMappingURL=SubjectSearchTest.js.map