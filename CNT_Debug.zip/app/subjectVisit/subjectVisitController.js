// this is the angular controller for the subject visit search landing page
// the form is subjectVisit.html
var app;
(function (app) {
    var SubjectVisitList;
    (function (SubjectVisitList) {
        var SubjectVisitController = (function () {
            function SubjectVisitController(dataAccessService, $state, $root, sharedProperties, $uibModal, $scope) {
                this.dataAccessService = dataAccessService;
                this.$uibModal = $uibModal;
                this.$scope = $scope;
                $root["subTitle"] = "Search Conflicts";
                this.state = $state;
                this.scope = $scope;
                this.showOnlyAssignedStudies = true;
                this.reprocessAllPackages = false;
                this.uibModal = $uibModal;
                this.checked = false;
                this.studies = [];
                this.dataService = dataAccessService;
                this.searchedPackage = new app.domain.SearchPackage();
                this.sharedProperties = sharedProperties;
                //console.log("Shared properties: " + this.sharedProperties.getKey("searchedStudy"));
                var searchedJsonString = this.sharedProperties.getKey("searchedStudy");
                if (searchedJsonString != null) {
                    var previousSelections = JSON.parse(searchedJsonString);
                    this.showOnlyAssignedStudies = previousSelections.showOnlyAssignedStudies;
                    this.selectedStudy = previousSelections.studyId;
                    this.loadCountryDropdownList();
                    this.selectedCountry = previousSelections.countryId;
                    this.loadProtocolDropdownList();
                    this.selectedProtocol = previousSelections.protocolId;
                    this.loadSiteDropdownList();
                    this.selectedSite = previousSelections.siteId;
                    this.selectedSubjectId = previousSelections.subjectId;
                    this.selectedPackageId = previousSelections.packageId;
                    this.loadVisitDropdownList();
                    this.selectedVisit = previousSelections.visitId;
                    this.searchSubjectVisit();
                }
                this.loadStudyDropdownList();
            }
            SubjectVisitController.prototype.populateOtherControls = function () {
                var selStudyID = this.selectedStudy;
                var selStudy = this.studies.filter(function (study) {
                    return (study.studyId == selStudyID);
                })[0];
                this.partialUploadConfigured = selStudy.partialUploadConfigured;
                this.loadStudyDropdownList();
                this.loadCountryDropdownList();
                this.loadProtocolDropdownList();
                this.loadSiteDropdownList();
                this.loadVisitDropdownList();
                this.resetSearchResultGrid();
            };
            SubjectVisitController.prototype.resetSearchResultGrid = function () {
                this.subjectVisitList = null;
            };
            SubjectVisitController.prototype.setSearchedPackage = function () {
                this.searchedPackage.studyId = this.selectedStudy;
                this.searchedPackage.countryId = this.selectedCountry;
                this.searchedPackage.protocolId = this.selectedProtocol;
                this.searchedPackage.siteId = this.selectedSite;
                this.searchedPackage.subjectId = this.selectedSubjectId;
                this.searchedPackage.packageId = this.selectedPackageId;
                this.searchedPackage.visitId = this.selectedVisit;
                this.searchedPackage.showOnlyAssignedStudies = this.showOnlyAssignedStudies;
                this.sharedProperties.setKey("searchedStudy", JSON.stringify(this.searchedPackage));
            };
            SubjectVisitController.prototype.populateControlsAfterProtocolSelectionUpdated = function () {
                this.loadCountryDropdownList();
                this.loadSiteDropdownList();
                this.loadVisitDropdownList();
            };
            SubjectVisitController.prototype.populateControlsAfterCountrySelectionUpdated = function () {
                this.loadSiteDropdownList();
                this.loadVisitDropdownList();
            };
            SubjectVisitController.prototype.loadStudyDropdownList = function () {
                var _this = this;
                var studyResource = this.dataService.getStudyResource($("#headerView").data("currentuser"));
                studyResource.query(function (data) {
                    _this.studies = data;
                }, function (data) { console.log("Error: " + data); });
            };
            SubjectVisitController.prototype.loadCountryDropdownList = function () {
                var _this = this;
                var countryResource = this.dataService.getSelectedCountryResource(this.selectedStudy, this.selectedProtocol);
                countryResource.query(function (data) {
                    _this.countries = data;
                }, function (data) { console.log("Error: " + data); });
            };
            SubjectVisitController.prototype.loadProtocolDropdownList = function () {
                var _this = this;
                var studyProtocolResource = this.dataService.getSelectedStudyProtocolResource(this.selectedStudy);
                studyProtocolResource.query(function (data) {
                    _this.studyProtocols = data;
                }, function (data) { console.log("Error: " + data); });
            };
            SubjectVisitController.prototype.loadSiteDropdownList = function () {
                var _this = this;
                var siteResource = this.dataService.getSelectedSiteResource(this.selectedStudy, this.selectedProtocol, this.selectedCountry);
                if (this.selectedStudy > 0 && this.selectedProtocol > 0) {
                    siteResource.query(function (data) {
                        _this.sites = data;
                    }, function (data) { console.log("Error: " + data); });
                }
                else {
                    this.sites = null;
                }
            };
            SubjectVisitController.prototype.loadVisitDropdownList = function () {
                var _this = this;
                var visitResource = this.dataService.getSelectedVisitResource(this.selectedStudy, this.selectedProtocol);
                if (this.selectedStudy > 0 && this.selectedProtocol > 0) {
                    visitResource.query(function (data) {
                        _this.visits = data;
                    }, function (data) { console.log("Error: " + data); });
                }
                else {
                    this.visits = null;
                }
            };
            SubjectVisitController.prototype.reloadPage = function (form) {
                this.selectedStudy = null;
                this.selectedProtocol = null;
                this.selectedSite = null;
                this.selectedSubjectId = null;
                this.selectedCountry = null;
                this.selectedDate = null;
                this.selectedVisit = null;
                this.selectedPackageId = null;
                form.$setPristine();
                form.$setUntouched();
                this.resetSearchResultGrid();
            };
            SubjectVisitController.prototype.searchSubjectVisit = function () {
                var _this = this;
                this.setSearchedPackage();
                var subjectVisitResource = this.dataService.getSelectedSubjectVisitListResource(this.selectedStudy, this.selectedCountry, this.selectedProtocol, this.selectedSite, this.selectedSubjectId, this.selectedVisit, this.selectedDate, this.selectedPackageId);
                subjectVisitResource.query(function (data) {
                    _this.subjectVisitList = data;
                }, function (data) { console.log("Error: " + data); });
                this.reprocessAllPackages = false;
            };
            SubjectVisitController.prototype.getMoreInfo = function (packageId) {
                this.state.go("compare", { packageId: packageId });
            };
            SubjectVisitController.prototype.resetSelection = function () {
                alert("test");
            };
            SubjectVisitController.prototype.resetSearchResult = function () {
                this.sharedProperties.setKey("searchedStudy", {});
                this.searchSubjectVisit();
                console.log("search reset");
                //this.state.reload();
            };
            SubjectVisitController.prototype.displayReprocess = function () {
                if (this.subjectVisitList === null || this.subjectVisitList === undefined) {
                    return false;
                }
                return this.subjectVisitList.filter(function (x) { return x.reprocess; }).length > 0;
            };
            SubjectVisitController.prototype.validateReprocessing = function () {
                var reprocessList = this.subjectVisitList.filter(function (x) { return x.reprocess; });
                if (reprocessList.length >= 10) {
                    this.reprocessingError = "Packages to reprocess: " + reprocessList.length + ". Please reduce amount to less then 10 to reprocess packages.";
                    return false;
                }
                return true;
            };
            SubjectVisitController.prototype.selectAllPackages = function () {
                var _this = this;
                this.subjectVisitList.map(function (x) { return x.reprocess = _this.reprocessAllPackages; });
            };
            SubjectVisitController.prototype.processedPackagesList = function (success) {
                if (this.reprocessedPackages !== null && this.reprocessedPackages.length > 0) {
                    return this.reprocessedPackages.filter(function (x) { return x.processed === success; });
                }
                return [];
            };
            SubjectVisitController.prototype.viewReprocessedPackages = function () {
                this.scope.reprocessedPackages = this.reprocessedPackages;
                this.uibModal.open({
                    animation: true,
                    ariaLabelledBy: 'modal-title',
                    ariaDescribedBy: 'modal-body',
                    templateUrl: 'app/subjectVisit/reprocessedPackages.html',
                    controller: 'ReprocessedPackagesController',
                    controllerAs: 'vm',
                    scope: this.scope,
                    windowClass: 'modal-xlarge',
                    backdrop: 'true',
                    keyboard: false
                }).closed.then(function () {
                    console.log('closed');
                });
            };
            SubjectVisitController.prototype.reprocessPackages = function () {
                var _this = this;
                this.reprocessingError = null;
                var reprocessList = this.subjectVisitList.filter(function (x) { return x.reprocess; });
                if (this.validateReprocessing()) {
                    this.reprocessedPackages = [];
                    this.setSearchedPackage();
                    this.dataService.reprocessPackages(reprocessList.map(function (x) { return x.packageID; }), $("#headerView").data("currentuser"), this.selectedStudy, this.selectedCountry, this.selectedProtocol, this.selectedSite, this.selectedSubjectId, this.selectedVisit, this.selectedDate, this.selectedPackageId).get(function (data) {
                        if (!data.result) {
                            console.log('Data null or empty.');
                        }
                        else {
                            _this.subjectVisitList = data.subjectVisitList;
                            reprocessList.map(function (r) {
                                var elements = _this.subjectVisitList.filter(function (x) { return x.packageID == r.packageID; });
                                if (elements.length > 0) {
                                    elements.map(function (e) { return e.reprocess = true; });
                                }
                            });
                            _this.reprocessedPackages = data.reprocessedPackages;
                        }
                        _this.reprocessAllPackages = false;
                    }, function (data) {
                        console.log('Failed: ' + data);
                        _this.reprocessAllPackages = false;
                    });
                }
            };
            SubjectVisitController.$inject = ["dataAccessService", "$state", "$rootScope", "sharedProperties", "$uibModal", "$scope"];
            return SubjectVisitController;
        }());
        SubjectVisitList.SubjectVisitController = SubjectVisitController;
        angular
            .module("dataConflictToolApp")
            .controller("SubjectVisitController", SubjectVisitController);
    })(SubjectVisitList = app.SubjectVisitList || (app.SubjectVisitList = {}));
})(app || (app = {}));
//# sourceMappingURL=subjectVisitController.js.map