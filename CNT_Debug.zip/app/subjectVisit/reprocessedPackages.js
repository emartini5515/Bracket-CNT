// this is the controller to handle the edit user in the manage user section
var app;
(function (app) {
    var SubjectVisitList;
    (function (SubjectVisitList) {
        var ReprocessedPackagesController = (function () {
            function ReprocessedPackagesController($scope, $uibModalInstance) {
                this.$scope = $scope;
                this.$uibModalInstance = $uibModalInstance;
                this.modalInstance = $uibModalInstance;
                this.reprocessedPackages = $scope.$parent.reprocessedPackages;
            }
            ReprocessedPackagesController.$inject = ["$scope", "$uibModalInstance"];
            return ReprocessedPackagesController;
        }());
        SubjectVisitList.ReprocessedPackagesController = ReprocessedPackagesController;
        angular
            .module("dataConflictToolApp")
            .controller("ReprocessedPackagesController", ReprocessedPackagesController);
    })(SubjectVisitList = app.SubjectVisitList || (app.SubjectVisitList = {}));
})(app || (app = {}));
//# sourceMappingURL=reprocessedPackages.js.map