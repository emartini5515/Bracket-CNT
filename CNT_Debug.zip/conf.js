﻿exports.config = {
    seleniumAddress: 'http://localhost:64015/',
    specs: ['/TestScripts/End2endTest.js']
};